# musdl

# NOTE:
_**The author of musdl does NOT condone piracy in any way, and is not responsible for anything that happens as a result of piracy arising from the use of mudl.**_

musdl (Musescore Downloader) is a Python script that I wrote to make it easier to download scores from Musescore.

## Why?
See the [original](https://github.com/Xmader/musescore-downloader) Javascript version for more infomation.

## takedown request something something
Take a look at this [issue](https://github.com/Xmader/musescore-downloader/issues/5) in the (same) Javascript downloader repo.

## Requirements
See `requirements.txt`.

## Hacking
```
git clone https://github.com/onyxware/musdl
cd musdl
# activate a virtualenv if you want
pip install -r requirements.txt
python3 setup.py install
```

## Install
`pip install musdl`

## License
[MIT](/LICENSE)

## Changelog

### 1.1.0
Added MusicXML download option, thanks to [JPFrancoia](https://github.com/JPFrancoia) for the update!

### 1.0.0
Initial version.
